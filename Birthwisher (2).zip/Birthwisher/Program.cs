﻿using System;
using System.Data.SqlClient;
using MySql.Data.MySqlClient;
using Twilio;
using Twilio.Rest.Api.V2010.Account;

namespace BirthdayWisher
{
    class Program
    {
        static void Main(string[] args)
        {
            string connectionString = "Server=localhost;Database=employee;User ID=root;Password=Papaji@9794;";
            string accountSid = "AC0dff85995d9a8811bb6dd45a641bcde0";
            string authToken = "fb5418e0c7c23908ed6de67fa8f93777";
            string twilioPhoneNumber = "+12097095995";
            MySqlConnection connection = new MySqlConnection(connectionString);

            try
            {
                connection.Open();
                string today = DateTime.Today.ToString("yyyy-MM-dd");
                string query = $"SELECT emp_name, mobile_number FROM emp WHERE DATE_FORMAT(date_of_birth, '%m-%d') = DATE_FORMAT('{today}', '%m-%d')";

                MySqlCommand cmd = new MySqlCommand(query, connection);
                MySqlDataReader reader = cmd.ExecuteReader();

                TwilioClient.Init(accountSid, authToken);

                while (reader.Read())
                {
                    string emp_name = reader.GetString("emp_name");
                    string mobile_number = reader.GetString("mobile_number");

                    string messageBody = $"Happy Birthday, {emp_name}! Wishing you a wonderful day. I'm sending this message by the Console App that I've been developed now usign Twilio API ";

                    var message = MessageResource.Create(
                        body: messageBody,
                        from: new Twilio.Types.PhoneNumber(twilioPhoneNumber),
                        to: new Twilio.Types.PhoneNumber(mobile_number)
                    );

                    Console.WriteLine($"Sent birthday wish to {emp_name} at {mobile_number}");
                }

                reader.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred: {ex.Message}");
            }
            finally
            {
                connection.Close();
            }
        }
    }
}
